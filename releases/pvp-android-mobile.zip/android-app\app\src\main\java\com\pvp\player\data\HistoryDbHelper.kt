package com.pvp.player.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class StreamHistoryItem(
    val id: Long,
    val url: String,
    val title: String,
    val durationStr: String,
    val timestamp: Long
)

class HistoryDbHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "pvp_streams.db"
        private const val DATABASE_VERSION = 1

        private const val TABLE_HISTORY = "stream_history"
        private const val COL_ID = "id"
        private const val COL_URL = "url"
        private const val COL_TITLE = "title"
        private const val COL_DURATION = "duration"
        private const val COL_TIMESTAMP = "timestamp"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE $TABLE_HISTORY (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_URL TEXT UNIQUE,
                $COL_TITLE TEXT,
                $COL_DURATION TEXT,
                $COL_TIMESTAMP INTEGER
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_HISTORY")
        onCreate(db)
    }

    fun addHistory(url: String, title: String, durationStr: String = "--:--") {
        try {
            val db = writableDatabase
            val values = ContentValues().apply {
                put(COL_URL, url)
                put(COL_TITLE, title.ifBlank { url })
                put(COL_DURATION, durationStr)
                put(COL_TIMESTAMP, System.currentTimeMillis())
            }
            db.insertWithOnConflict(TABLE_HISTORY, null, values, SQLiteDatabase.CONFLICT_REPLACE)
        } catch (_: Exception) {}
    }

    fun getRecentHistory(limit: Int = 30): List<StreamHistoryItem> {
        val list = mutableListOf<StreamHistoryItem>()
        try {
            val db = readableDatabase
            val cursor = db.query(
                TABLE_HISTORY,
                arrayOf(COL_ID, COL_URL, COL_TITLE, COL_DURATION, COL_TIMESTAMP),
                null, null, null, null,
                "$COL_TIMESTAMP DESC",
                limit.toString()
            )
            cursor.use {
                while (it.moveToNext()) {
                    list.add(
                        StreamHistoryItem(
                            id = it.getLong(0),
                            url = it.getString(1),
                            title = it.getString(2) ?: it.getString(1),
                            durationStr = it.getString(3) ?: "--:--",
                            timestamp = it.getLong(4)
                        )
                    )
                }
            }
        } catch (_: Exception) {}
        return list
    }

    fun deleteItem(id: Long) {
        try {
            writableDatabase.delete(TABLE_HISTORY, "$COL_ID = ?", arrayOf(id.toString()))
        } catch (_: Exception) {}
    }

    fun clearAll() {
        try {
            writableDatabase.delete(TABLE_HISTORY, null, null)
        } catch (_: Exception) {}
    }
}
